# AHAguilera — Brand Kit

Kit completo de identidad de marca. Todo es estático y autocontenido.

## Estructura

```
ahaguilera-brand-kit/
├── README.md                       ← este archivo
├── index.html                      ← brand book visual (abrir en navegador)
├── manifest/
│   └── site.webmanifest            ← PWA manifest
├── favicons/
│   ├── favicon.svg                 ← vectorial, multi-escala
│   ├── favicon.ico                 ← 16/32/48 embebido
│   ├── favicon-16x16.png
│   ├── favicon-32x32.png
│   ├── favicon-48x48.png
│   ├── favicon-96x96.png
│   └── apple-touch-icon.png        ← 180×180 iOS
├── pwa/
│   ├── android-chrome-192x192.png
│   ├── android-chrome-512x512.png
│   ├── maskable-192x192.png        ← full-bleed teal, safe-zone 80%
│   ├── maskable-512x512.png
│   └── maskable.svg
├── social/
│   ├── og-image.png                ← 1200×630 Open Graph
│   └── twitter-card.png            ← 1200×600 Twitter/X
└── logos/
    ├── monogram.svg / .png         ← cuadrado teal + AHA tricolor
    ├── monogram-white.svg / .png   ← solo AHA blanco (fondo oscuro)
    ├── monogram-black.svg / .png   ← solo AHA negro (fondo claro)
    ├── monogram-lime.svg / .png    ← solo AHA lime
    ├── monogram-on-beige.svg / .png← caja beige + AHA negro
    ├── monogram-lime-bg.svg / .png ← caja lime + AHA negro
    ├── wordmark-dark.svg / .png    ← AHAguilera + tagline (para fondo oscuro)
    ├── wordmark-light.svg / .png   ← variante para fondo beige
    ├── wordmark-white.svg / .png
    ├── wordmark-black.svg / .png
    ├── wordmark-lime.svg / .png
    ├── lockup-vertical.svg / .png  ← monograma + wordmark apilado
    ├── lockup-vertical-light.svg / .png
    └── lockup-vertical-white.svg / .png
```

## Uso rápido — HTML head

```html
<link rel="icon" href="/favicons/favicon.svg" type="image/svg+xml">
<link rel="icon" href="/favicons/favicon.ico" sizes="any">
<link rel="apple-touch-icon" href="/favicons/apple-touch-icon.png">
<link rel="manifest" href="/manifest/site.webmanifest">
<meta name="theme-color" content="#024653">
<meta property="og:image" content="/social/og-image.png">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:image" content="/social/twitter-card.png">
```

## Tokens de marca

| Token              | Hex       | Uso                                  |
|--------------------|-----------|--------------------------------------|
| `--surface`        | `#171614` | Fondo principal dark                 |
| `--surface-teal`   | `#024653` | Fondo del monograma, themable        |
| `--accent`         | `#CFF434` | Lime — CTAs, links, AHA highlight    |
| `--accent-secondary`| `#07D16E`| Verde — states OK, AHA accent        |
| `--text-primary`   | `#EAF4F5` | Texto principal sobre dark           |
| `--beige-surface`  | `#F5F0EB` | Fondo modo claro                     |

## Tipografía recomendada

| Rol              | Familia                            | Pesos | Uso                       |
|------------------|------------------------------------|-------|---------------------------|
| Display/UI       | `Inter` (fallback `system-ui`)     | 700/800 | Titulares, logo, AHA    |
| Body             | `Inter` (fallback `system-ui`)     | 400/500 | Párrafos, UI            |
| Monoespaciado    | `JetBrains Mono`                   | 400/600 | Código, tokens, meta    |

> El sistema actual usa `system-ui` puro. Para marca consistente en web, se
> recomienda cargar Inter como fuente web (autohospedada vía `@fontsource/inter`).
